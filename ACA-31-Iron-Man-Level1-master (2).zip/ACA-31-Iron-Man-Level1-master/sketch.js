
var bg, backgroundImg;

function preload() {
  backgroundImg = loadImage("images/bg.jpg");
 
}

function setup() {
  createCanvas(1000, 600);
  bg = createSprite(580,300);
 
}

function draw() {
  
 
    
    drawSprites();
   
}

